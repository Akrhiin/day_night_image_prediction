#file:    day_night_classifier.py
#author:  michael pace
#created: 12.1?.2024 [from original, 12.06.2024]
#updated: 12.21.2024
#
# description:
#   Machine learning system that classifies images as either daytime or nighttime
#   scenes, using computer vision and supervised learning techniques. The program
#   implements a Random Forest classifier to learn patterns from labeled training
#   data of day and night images.
#
#    Required Modules: scikit-learn, opencv (cv2)
#
#   1. Loading and preprocessing images (grayscale conversion, resizing)
#   2. Extracting features through pixel intensity values
#   3. Training an ensemble of decision trees (Random Forest)
#   4. Predicting new images with probability estimates
#
#   Key AI concepts utilized:
#   - Supervised Learning: Uses labeled training data (day/night) to learn a
#     classification function mapping inputs to discrete categories
#   - Ensemble Learning: Random Forest combines multiple decision trees to reduce
#     overfitting and improve generalization through voting
#   - Feature Extraction: Converts raw pixel data into a format suitable for
#     machine learning through grayscale conversion and standardization
#   - Decision Trees: Each tree in the forest learns a hierarchical set of rules
#     for classification, based on pixel intensity patterns
#   - Cross-Validation: Splits data into training/testing sets to evaluate model
#     performance on unseen data
#   - Statistical Learning: Uses StandardScaler for feature normalization and
#     probability estimation for predictions
#   - Computer Vision: Applies image processing techniques (cv2) for input
#     preparation and feature extraction

# IMPORTS
import os, random
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import cv2

# FUNCTIONS
def load_images(day_folder, night_folder, image_size=(64, 64)):
    """
    Load images from day, night folders; convert to grayscale, resize.

    Args:
    day_folder (str): Path to folder with day images
    night_folder (str): Path to folder with night images
    image_size (tuple): Desired image size for resizing

    Returns:
    tuple: X (image features), y (labels)
    """
    images = []
    labels = []

    # load day images
    for filename in os.listdir(day_folder): # for each day image file:
        img_path = os.path.join(day_folder, filename) # file path
        try:
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)    # read image
            img_resized = cv2.resize(img, image_size)           # resize image
            images.append(img_resized.flatten())                # append image data
            labels.append(1)  # 1 for day                       # append image label day (1)
        except Exception as e:
            print(f"Error processing day image {filename}: {e}")    # otherwise yell about it

    # load night images
    for filename in os.listdir(night_folder): # for each night image file
        img_path = os.path.join(night_folder, filename) #file path
        try:
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)    # read image
            img_resized = cv2.resize(img, image_size)           # resize image
            images.append(img_resized.flatten())                # append image data
            labels.append(0)  # 0 for night                     # append image label night (0)
        except Exception as e:
            print(f"Error processing night image {filename}: {e}")  # otherwise make a scene

    return np.array(images), np.array(labels) # return (<image arr>,<label arr>)

def train_day_night_classifier(day_folder, night_folder):
    """
    Train a Random Forest Classifier to distinguish between day, night images.

    Args:
    day_folder (str): Path to folder with day images
    night_folder (str): Path to folder with night images

    Returns:
    tuple: Trained model, scaler, classification report
    """
    # load images from day, night as tuple
    X, y = load_images(day_folder, night_folder)

    # split data
     # (parameters were being a bit funky but this seems to work)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # scale features:
    # done independently for each column in data, feature-wise
    # adjusts variables to use the same scale, makes it so they can all be worked with together
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # train random forest classifier (again not sure on params but it ain't broke)
    #  ^^^^ creates a number of decision trees, unifies into single tree based off occurrances
    rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_classifier.fit(X_train_scaled, y_train) # build forest of trees from training set

    # predictions
    y_pred = rf_classifier.predict(X_test_scaled) # unify trees weighted by probability estimates
                                                    # ^^^^ predicted class is the one w/ highest
                                                    #  mean probability estimate across trees
                                                    #  (most occurrances)
    # generate classification report
    report = classification_report(y_test, y_pred, target_names=['Night', 'Day'])

    return rf_classifier, scaler, report # return trained classifier, scaled data, report

def classify_image(image_path, model, scaler, image_size=(64, 64)):
    """
    Classify a single image, return probability of being day image.

    Args:
    image_path (str): Path to the image to classify
    model (sklearn.ensemble.RandomForestClassifier): Trained classifier
    scaler (sklearn.preprocessing.StandardScaler): Feature scaler
    image_size (tuple): Desired image size for resizing

    Returns:
    tuple: Probability of day, probability of night
    """
    try:
        img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)   # read image in grayscale
        img_resized = cv2.resize(img, image_size)            # resize image [64px,64px]
        img_flattened = img_resized.flatten().reshape(1, -1) # flatten image

        img_scaled = scaler.transform(img_flattened) # scale the image

        # predict probabilities
        proba = model.predict_proba(img_scaled)[0] # predict probabilities for each image

        return { # return tuple (<day prob>,<night prob>)
            'day_probability': proba[1],
            'night_probability': proba[0]
        }
    except Exception as e: # yell more
        print(f"Error classifying image: {e}")
        return None

# MAIN
if __name__ == "__main__":
    # day, night image paths
    DAY_FOLDER = 'day_images_training'
    NIGHT_FOLDER = 'night_images_training'
    # testing image set dir
    TESTING_FOLDER = 'images_testing'

    # train model
    model, scaler, report = train_day_night_classifier(DAY_FOLDER, NIGHT_FOLDER)
    print("Classification Report:")
    print(report)

    # classifying single image
    #!!! fix image path
    TEST_IMAGE = random.choice(os.listdir('images_testing')) # select random img from testing set
    print('\nImage File: '+TEST_IMAGE) # print tested image
    result = classify_image("images_testing/"+TEST_IMAGE, model, scaler)  # classify selected image (test night/day)
    if result: # if things don't break => print probability of img [night/day]
        print("\nImage Classification Probabilities:")
        print(f"Day Probability: {result['day_probability']:.2%}")
        print(f"Night Probability: {result['night_probability']:.2%}")




#o7
